<?php

include 'config/koneksi.php';

$name = "administrator";
$email = "admin@gmail.com";
$password = password_hash("admin123", PASSWORD_DEFAULT);
$role = "admin";

// Masukkan ke tabel t_users
$sql = "INSERT INTO t_users (name, email, password, role)
        VALUES ('$name', '$email', '$password', '$role')";

if (mysqli_query($koneksi, $sql)) {

    echo "User admin berhasil dibuat.";

} else {

    echo "Gagal membuat user: " . mysqli_error($koneksi);

}

?>